let req = document.getElementById('get');
let send = document.getElementById('data');

chrome.runtime.onMessage.addListener( 
    (request,sender,sendResponse) => {
        let data = request.data;
        send.append(JSON.stringify(data))
        // alert(data);
    }
)

req.addEventListener('click' , async () => {
    //get current active tab
    let [tab] = await chrome.tabs.query({active : true , currentWindow : true});
    
    // alert('hello');
    //Excecuting script to get table data
    chrome.scripting.executeScript({
        target : {tabId : tab.id},
        func : getData
    });
})

function getData(){
    
    let data = document.getElementsByClassName("table tl-dataTable JS_export_btn JS_autoFetchDataTables datatable-sticky-header");
    chrome.runtime.sendMessage({data})
    // alert(data);
}