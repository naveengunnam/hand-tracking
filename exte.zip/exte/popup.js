let req = document.getElementById('get');
let med_vol = document.getElementById('med_vol');
let mea_vol = document.getElementById('mea_vol');
let med_per = document.getElementById('med_per');
let mea_per = document.getElementById('mea_per');
let ch_per = document.getElementById('ch_per');
let vol_ch = document.getElementById('vol_ch');


chrome.runtime.onMessage.addListener( 
    (request,sender,sendResponse) => {
        let data = request.data;
        let document = new DOMParser().parseFromString(data, "text/html");
        let table = document.getElementsByClassName("table tl-dataTable JS_export_btn JS_autoFetchDataTables datatable-sticky-header dataTable no-footer")[1];
        let table_data = table.getElementsByTagName('tbody')[0]
        // alert(table_data)
        let rows = table_data.getElementsByTagName('tr')
        let first_day
        let first_vol
        // alert(rows.length)
        let volsum =0
        let persum =0
        const vols = [];
        const pers = [];
        for(var i = 0; i < rows.length ; i++) {
            let tds    = rows[i].getElementsByTagName('td');
            let delvol = tds[1].getElementsByClassName('text-lg-right')[0].innerHTML
            let delper = tds[3].getElementsByClassName('text-lg-right')[0].innerHTML
            volsum += Math.round(delvol)
            persum += Math.round(delper.slice(0, -1))
            vols.push(Math.round(delvol))
            pers.push(Math.round(delper.slice(0, -1)))
            if(i==0) {
                first_day = Math.round(delper.slice(0, -1))
                first_vol = Math.round(delvol)
            }


        }
        
        mea_vol.append(Math.round(volsum/rows.length));
        mea_per.append(Math.round(persum/rows.length));
        let med_vols = median(vols)
        med_vol.append(med_vols);
        let med_pers = median(pers)
        med_per.append(med_pers);
        let change_per = Math.round( ( ( first_day - med_pers ) / med_pers ) * 100 )
        ch_per.append(change_per)
        let vol_per =  Math.round( ( ( first_vol - med_vols ) / first_vol ) * 100 )
        vol_ch.append(vol_per)
         

    }
)



// req.addEventListener('click' , async () => {
//     //get current active tab
//     let [tab] = await chrome.tabs.query({active : true , currentWindow : true});
    
//     // alert('hello');
//     //Excecuting script to get table data
//     chrome.scripting.executeScript({
//         target : {tabId : tab.id},
//         func : getData
//     });
// })
async function get()  {
    //get current active tab
    let [tab] = await chrome.tabs.query({active : true , currentWindow : true});
    
    // alert('hello');
    //Excecuting script to get table data
    chrome.scripting.executeScript({
        target : {tabId : tab.id},
        func : getData
    });
}

function median(values){
    if(values.length ===0) throw new Error("No inputs");
  
    values.sort(function(a,b){
      return a-b;
    });
  
    var half = Math.floor(values.length / 2);
    
    if (values.length % 2)
      return values[half];
    
    return (values[half - 1] + values[half]) / 2.0;
  }


get();


function getData(){
    
    let data = document.documentElement.outerHTML;
    chrome.runtime.sendMessage({data})
    // alert(data);
}